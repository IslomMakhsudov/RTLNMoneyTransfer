﻿namespace RTLN.MoneyTransfer.WebApi.Modules.Transfer.State.ModelRequests
{
    public class StateOfTransferModelRequest
    {
        public string OriginatorReferenceNumber { get; set; }
    }
}
