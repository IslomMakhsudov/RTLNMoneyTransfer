﻿namespace RTLN.MoneyTransfer.WebApi.Modules.Transfer.State.Services
{
    public class StateOfTransferService
    {
    }
}
