﻿namespace RTLN.MoneyTransfer.WebApi.Modules.Transfer.State.Services
{
    public interface IStateOfTransferService
    {
    }
}
