﻿namespace RTLN.MoneyTransfer.WebApi.Modules.Transfer.Check.Services
{
    public interface ICheckTransferService
    {
    }
}
