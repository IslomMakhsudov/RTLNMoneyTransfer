﻿namespace RTLN.MoneyTransfer.WebApi.Modules.Transfer.Check.Services
{
    public class CheckTransferService
    {
    }
}
