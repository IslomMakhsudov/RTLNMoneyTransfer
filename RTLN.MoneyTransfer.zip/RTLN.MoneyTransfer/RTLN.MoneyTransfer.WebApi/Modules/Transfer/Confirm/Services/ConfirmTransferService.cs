﻿namespace RTLN.MoneyTransfer.WebApi.Modules.Transfer.Confirm.Services
{
    public class ConfirmTransferService
    {
    }
}
