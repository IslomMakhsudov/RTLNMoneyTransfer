﻿namespace RTLN.MoneyTransfer.WebApi.Modules.Transfer.Confirm.Services
{
    public interface IConfirmTransferService
    {
    }
}
