﻿namespace RTLN.MoneyTransfer.WebApi.Modules.ParticipantList.Services
{
    public class ParticipantListService
    {
    }
}
