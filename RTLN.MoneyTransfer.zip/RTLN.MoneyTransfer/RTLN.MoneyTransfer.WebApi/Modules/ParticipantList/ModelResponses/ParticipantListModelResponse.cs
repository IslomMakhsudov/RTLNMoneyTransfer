﻿using RTLN.MoneyTransfer.Core.Entities;

namespace RTLN.MoneyTransfer.WebApi.Modules.ParticipantList.ModelResponses
{
    public class ParticipantListModelResponse
    {
        List<FullParticipant> ParticipantList { get; set; }
    }
}
