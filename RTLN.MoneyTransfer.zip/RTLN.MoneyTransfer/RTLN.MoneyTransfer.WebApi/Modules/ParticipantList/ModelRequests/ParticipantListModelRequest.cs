﻿using RTLN.MoneyTransfer.Core.Entities;

namespace RTLN.MoneyTransfer.WebApi.Modules.ParticipantList.ModelRequests
{
    public class ParticipantListModelRequest
    {
        public ParticipantListOriginator Originator { get; set; }
    }
}
