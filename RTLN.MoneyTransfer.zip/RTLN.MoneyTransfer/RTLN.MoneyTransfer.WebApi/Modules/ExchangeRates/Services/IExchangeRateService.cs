﻿namespace RTLN.MoneyTransfer.WebApi.Modules.ExchangeRates.Services
{
    public interface IExchangeRateService
    {

    }
}
