﻿using RTLN.MoneyTransfer.Core.Entities;

namespace RTLN.MoneyTransfer.WebApi.Modules.ReceiverList.ModelRequests
{
    public class ReceiverListModelRequest
    {
        public Originator Originator { get; set; }
    }
}
