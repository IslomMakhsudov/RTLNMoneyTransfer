﻿namespace RTLN.MoneyTransfer.WebApi.Modules.ReceiverList.Services
{
    public class ReceiverListService
    {
    }
}
