﻿namespace RTLN.MoneyTransfer.WebApi.Modules.ReceiverList.Services
{
    public interface IReceiverListService
    {
    }
}
